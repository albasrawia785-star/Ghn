package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.AppDatabase
import com.example.data.POSRepository
import com.example.ui.*
import com.example.ui.theme.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // Initialize Room Database & Repository
                val context = LocalContext.current
                val database = remember { AppDatabase.getDatabase(context) }
                val repository = remember { POSRepository(database.posDao()) }
                
                // Instantiate ViewModel with Custom Factory
                val posViewModel: POSViewModel = viewModel(
                    factory = POSViewModelFactory(repository, context)
                )

                // Force layout direction to RTL for native Arabic presentation
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    val isLoggedIn by posViewModel.isLoggedIn.collectAsState()
                    val isTrialExpired by posViewModel.isTrialExpired.collectAsState()

                    if (isTrialExpired) {
                        TrialExpiredScreen()
                    } else if (!isLoggedIn) {
                        LoginScreen(viewModel = posViewModel)
                    } else {
                        androidx.activity.compose.BackHandler {
                            // Prevent back button from returning to login or exiting unexpectedly, minimize task instead
                            (context as? android.app.Activity)?.moveTaskToBack(true)
                        }
                        Scaffold(
                            modifier = Modifier.fillMaxSize(),
                            containerColor = POSBackground,
                            bottomBar = {
                                POSBottomNavigation(viewModel = posViewModel)
                            }
                        ) { innerPadding ->
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(innerPadding)
                            ) {
                                POSMainContent(viewModel = posViewModel)
                                
                                // Bottom Sheet for Cart Detail
                                CartSheetOverlay(viewModel = posViewModel)

                                // Checkout Dialog
                                CheckoutDialogOverlay(viewModel = posViewModel)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun POSMainContent(viewModel: POSViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    // Smooth transition animations between tabs (150ms-200ms)
    AnimatedContent(
        targetState = currentTab,
        transitionSpec = {
            fadeIn(animationSpec = androidx.compose.animation.core.tween(150)) togetherWith
            fadeOut(animationSpec = androidx.compose.animation.core.tween(150))
        },
        label = "POSScreenTransition"
    ) { tabIndex ->
        when (tabIndex) {
            0 -> HomeScreen(viewModel = viewModel)
            1 -> OrdersScreen(viewModel = viewModel)
            2 -> MenuScreen(viewModel = viewModel)
            3 -> SettingsScreen(viewModel = viewModel)
        }
    }
}

@Composable
fun POSBottomNavigation(viewModel: POSViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()

    NavigationBar(
        containerColor = POSSurface,
        tonalElevation = 4.dp,
        modifier = Modifier.navigationBarsPadding()
    ) {
        // Tab 1: الرئيسية
        NavigationBarItem(
            selected = currentTab == 0,
            onClick = { viewModel.selectTab(0) },
            modifier = Modifier.testTag("nav_tab_home"),
            label = { Text("الرئيسية", fontSize = 11.sp, fontWeight = if (currentTab == 0) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal) },
            icon = { Icon(Icons.Default.Storefront, contentDescription = "الرئيسية") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = POSPrimary, // Navy capsule bg
                selectedIconColor = POSAccent, // Gold icon
                selectedTextColor = POSPrimary,
                unselectedIconColor = TextMuted, // Gray icon
                unselectedTextColor = TextMuted // Gray text
            )
        )

        // Tab 2: الطلبات
        NavigationBarItem(
            selected = currentTab == 1,
            onClick = { viewModel.selectTab(1) },
            modifier = Modifier.testTag("nav_tab_orders"),
            label = { Text("الطلبات", fontSize = 11.sp, fontWeight = if (currentTab == 1) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal) },
            icon = { Icon(Icons.Default.History, contentDescription = "الطلبات") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = POSPrimary,
                selectedIconColor = POSAccent,
                selectedTextColor = POSPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            )
        )

        // Tab 3: المنيو
        NavigationBarItem(
            selected = currentTab == 2,
            onClick = { viewModel.selectTab(2) },
            modifier = Modifier.testTag("nav_tab_menu"),
            label = { Text("المنيو", fontSize = 11.sp, fontWeight = if (currentTab == 2) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal) },
            icon = { Icon(Icons.Default.RestaurantMenu, contentDescription = "المنيو") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = POSPrimary,
                selectedIconColor = POSAccent,
                selectedTextColor = POSPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            )
        )

        // Tab 4: الإعدادات
        NavigationBarItem(
            selected = currentTab == 3,
            onClick = { viewModel.selectTab(3) },
            modifier = Modifier.testTag("nav_tab_settings"),
            label = { Text("الإعدادات", fontSize = 11.sp, fontWeight = if (currentTab == 3) androidx.compose.ui.text.font.FontWeight.Bold else androidx.compose.ui.text.font.FontWeight.Normal) },
            icon = { Icon(Icons.Default.Settings, contentDescription = "الإعدادات") },
            colors = NavigationBarItemDefaults.colors(
                indicatorColor = POSPrimary,
                selectedIconColor = POSAccent,
                selectedTextColor = POSPrimary,
                unselectedIconColor = TextMuted,
                unselectedTextColor = TextMuted
            )
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartSheetOverlay(viewModel: POSViewModel) {
    val showCartSheet by viewModel.showCartSheet.collectAsState()

    if (showCartSheet) {
        ModalBottomSheet(
            onDismissRequest = { viewModel.setShowCartSheet(false) },
            containerColor = POSSurface,
            shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
            modifier = Modifier.testTag("cart_bottom_sheet")
        ) {
            CartSheetContent(
                viewModel = viewModel,
                onClose = { viewModel.setShowCartSheet(false) },
                onCheckoutClick = {
                    viewModel.setShowCartSheet(false)
                    viewModel.setShowPaymentDialog(true)
                }
            )
        }
    }
}

@Composable
fun CheckoutDialogOverlay(viewModel: POSViewModel) {
    val showPaymentDialog by viewModel.showPaymentDialog.collectAsState()

    if (showPaymentDialog) {
        PaymentDialog(
            viewModel = viewModel,
            onDismiss = { viewModel.setShowPaymentDialog(false) },
            onPaymentSuccess = {
                // Success actions are handled inside the callback
            }
        )
    }
}
