package com.example.utils

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.util.*

object BluetoothPrinterService {
    private const val TAG = "BT_PrinterService"
    private val PRINTER_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    // Checks if the device name indicates it's a valid thermal printer
    fun isThermalPrinter(name: String?, majorClass: Int, deviceClass: Int): Boolean {
        val nameLower = name?.lowercase() ?: return false
        
        // Exclude phones, computers, wearables, cars, etc.
        val isExcluded = nameLower.contains("phone") || nameLower.contains("galaxy") || 
                nameLower.contains("iphone") || nameLower.contains("samsung") || 
                nameLower.contains("pixel") || nameLower.contains("redmi") || 
                nameLower.contains("xiaomi") || nameLower.contains("huawei") || 
                nameLower.contains("oppo") || nameLower.contains("realme") || 
                nameLower.contains("oneplus") || nameLower.contains("ipad") || 
                nameLower.contains("macbook") || nameLower.contains("pc") || 
                nameLower.contains("laptop") || nameLower.contains("desktop") || 
                nameLower.contains("tv") || nameLower.contains("speaker") || 
                nameLower.contains("headset") || nameLower.contains("watch") || 
                nameLower.contains("fitbit") || nameLower.contains("car") || 
                nameLower.contains("audio") || nameLower.contains("media")

        if (isExcluded) return false

        // Acceptable major/minor device classes
        val isAcceptableClass = majorClass == android.bluetooth.BluetoothClass.Device.Major.IMAGING ||
                majorClass == android.bluetooth.BluetoothClass.Device.Major.UNCATEGORIZED ||
                deviceClass == 1664 || deviceClass == 1668 || deviceClass == 1680

        // Explicit name checks
        val matchesName = nameLower.contains("print") || nameLower.contains("thermal") || 
                nameLower.contains("pos") || nameLower.contains("mpt") || 
                nameLower.contains("xp-") || nameLower.contains("zj") || 
                nameLower.contains("goojprt") || nameLower.contains("bixolon") || 
                nameLower.contains("sewoo") || nameLower.contains("epson") || 
                nameLower.contains("star") || nameLower.contains("58mm") || 
                nameLower.contains("80mm")

        return isAcceptableClass && matchesName
    }

    // Scans for nearby active devices, filters them strictly to thermal printers within ~2 meters (RSSI >= -65 dBm)
    @SuppressLint("MissingPermission")
    fun scanNearbyPrinters(
        context: Context,
        onDeviceFound: (name: String, address: String, rssi: Int, distance: Double) -> Unit,
        onScanFinished: () -> Unit
    ): BroadcastReceiver? {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return null
        if (!adapter.isEnabled) return null

        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val action = intent.action
                if (BluetoothDevice.ACTION_FOUND == action) {
                    val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    val rssi = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                    
                    if (device != null) {
                        val name = device.name ?: "Unknown"
                        val address = device.address ?: ""
                        val btClass = device.bluetoothClass
                        val majorClass = btClass?.majorDeviceClass ?: 0
                        val deviceClass = btClass?.deviceClass ?: 0

                        // Calculate approximate distance using log-distance path loss formula
                        // Distance = 10 ^ ((Measured Power - RSSI) / (10 * N))
                        // We assume Measured Power at 1m is -60 dBm, N is 2.2
                        val distance = Math.pow(10.0, (-60.0 - rssi) / 22.0)

                        // Strict filter:
                        // 1. Is thermal printer?
                        // 2. Is nearby (within 2 meters, RSSI >= -65 dBm)?
                        if (isThermalPrinter(name, majorClass, deviceClass)) {
                            if (rssi >= -65) {
                                onDeviceFound(name, address, rssi, distance)
                            }
                        }
                    }
                } else if (BluetoothAdapter.ACTION_DISCOVERY_FINISHED == action) {
                    onScanFinished()
                }
            }
        }

        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        context.registerReceiver(receiver, filter)

        adapter.startDiscovery()
        return receiver
    }

    // Connects to Bluetooth thermal printer and prints the high-resolution receipt Bitmap
    @SuppressLint("MissingPermission")
    suspend fun printReceiptViaBluetooth(
        context: Context,
        deviceAddress: String,
        bitmap: Bitmap
    ): Boolean = withContext(Dispatchers.IO) {
        val adapter = BluetoothAdapter.getDefaultAdapter() ?: return@withContext false
        if (!adapter.isEnabled) return@withContext false

        val device = adapter.getRemoteDevice(deviceAddress) ?: return@withContext false
        var socket: BluetoothSocket? = null
        var outputStream: OutputStream? = null

        try {
            socket = device.createRfcommSocketToServiceRecord(PRINTER_UUID)
            // Cancel discovery to free up bandwidth and ensure solid socket connection
            adapter.cancelDiscovery()
            
            socket.connect()
            outputStream = socket.outputStream

            // 1. Initialize printer
            outputStream.write(byteArrayOf(0x1B, 0x40)) // ESC @
            
            // 2. Print bitmap data converted to ESC/POS raster bit image format
            val printBytes = convertBitmapToEscPosBytes(bitmap)
            outputStream.write(printBytes)

            // 3. Feed paper and cut (or feed enough lines)
            outputStream.write(byteArrayOf(0x1B, 0x64, 0x05)) // ESC d 5 (feed 5 lines)
            outputStream.write(byteArrayOf(0x1D, 0x56, 0x42, 0x00)) // GS V 66 0 (cut paper)

            outputStream.flush()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Bluetooth printing failed: ", e)
            false
        } finally {
            try {
                outputStream?.close()
                socket?.close()
            } catch (ex: Exception) {
                Log.e(TAG, "Socket cleanup error: ", ex)
            }
        }
    }

    // Converts a Bitmap into an ESC/POS binary raster image command stream (GS v 0 m xL xH yL yH d1...dn)
    private fun convertBitmapToEscPosBytes(bitmap: Bitmap): ByteArray {
        val width = bitmap.width
        val height = bitmap.height
        
        // ESC/POS raster image format width must be multiple of 8 (1 byte = 8 pixels)
        val byteWidth = (width + 7) / 8
        val commandLength = 8 + (byteWidth * height)
        val bytes = ByteArray(commandLength)

        // GS v 0 0 xL xH yL yH
        bytes[0] = 0x1D // GS
        bytes[1] = 0x76 // v
        bytes[2] = 0x30 // 0
        bytes[3] = 0x00 // m = 0 (normal size)
        
        bytes[4] = (byteWidth % 256).toByte() // xL
        bytes[5] = (byteWidth / 256).toByte() // xH
        bytes[6] = (height % 256).toByte()    // yL
        bytes[7] = (height / 256).toByte()    // yH

        var index = 8
        for (y in 0 until height) {
            for (xByte in 0 until byteWidth) {
                var currentByte = 0
                for (bit in 0 until 8) {
                    val xPixel = xByte * 8 + bit
                    if (xPixel < width) {
                        val pixel = bitmap.getPixel(xPixel, y)
                        val alpha = Color.alpha(pixel)
                        val red = Color.red(pixel)
                        val green = Color.green(pixel)
                        val blue = Color.blue(pixel)
                        
                        // Treat transparent as white, and calculate luminance threshold
                        val isBlack = if (alpha < 50) {
                            false
                        } else {
                            val luminance = (0.299 * red + 0.587 * green + 0.114 * blue)
                            luminance < 160 // Black pixel threshold
                        }
                        
                        if (isBlack) {
                            currentByte = currentByte or (1 shl (7 - bit))
                        }
                    }
                }
                bytes[index++] = currentByte.toByte()
            }
        }
        return bytes
    }
}
