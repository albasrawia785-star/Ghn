package com.example.utils

import android.content.Context
import org.json.JSONObject
import java.io.File

object AppConfig {
    private const val FILE_NAME = "coco.json"

    var restaurantName: String = "مطعم وكافيه النخبة"
    var restaurantPhone: String = "07810936407"
    var restaurantAddress: String = "بغداد - الكرادة"
    var ownerName: String = "علي"

    fun load(context: Context) {
        try {
            // Step 1: Initialize defaults from assets/coco.json
            try {
                context.assets.open("coco.json").use { inputStream ->
                    val size = inputStream.available()
                    val buffer = ByteArray(size)
                    inputStream.read(buffer)
                    val jsonStr = String(buffer, Charsets.UTF_8)
                    val json = JSONObject(jsonStr)
                    restaurantName = json.optString("STORE_NAME", "مطعم وكافيه النخبة")
                    restaurantPhone = json.optString("STORE_PHONE", "07810936407")
                    ownerName = json.optString("OWNER_NAME", "علي")
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }

            // Step 2: Load any locally saved overrides
            val file = File(context.filesDir, FILE_NAME)
            if (file.exists()) {
                val jsonStr = file.readText()
                val json = JSONObject(jsonStr)
                restaurantName = json.optString("restaurantName", restaurantName)
                restaurantPhone = json.optString("restaurantPhone", restaurantPhone)
                restaurantAddress = json.optString("restaurantAddress", restaurantAddress)
                ownerName = json.optString("ownerName", ownerName)
            } else {
                save(context)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun save(context: Context) {
        try {
            val file = File(context.filesDir, FILE_NAME)
            val json = JSONObject()
            json.put("restaurantName", restaurantName)
            json.put("restaurantPhone", restaurantPhone)
            json.put("restaurantAddress", restaurantAddress)
            json.put("ownerName", ownerName)
            file.writeText(json.toString(4))
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}
