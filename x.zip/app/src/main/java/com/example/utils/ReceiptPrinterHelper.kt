package com.example.utils

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.*
import android.os.Bundle
import android.os.CancellationSignal
import android.os.ParcelFileDescriptor
import android.print.PageRange
import android.print.PrintAttributes
import android.print.PrintDocumentAdapter
import android.print.PrintDocumentInfo
import android.print.PrintManager
import android.print.pdf.PrintedPdfDocument
import com.example.data.Invoice
import com.example.data.InvoiceItem
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

object ReceiptPrinterHelper {

    fun printReceipt(context: Context, invoice: Invoice, items: List<InvoiceItem>) {
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val paperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        val printerName = prefs.getString("selected_printer_name", "طابعة الكاشير الافتراضية (Xprinter)") ?: "طابعة الكاشير الافتراضية (Xprinter)"
        
        val bitmap = generateReceiptBitmap(context, invoice, items, paperWidth)
        val jobName = "وصل_رقم_${invoice.invoiceNumber}"

        val activity = context as? android.app.Activity ?: return
        activity.runOnUiThread {
            try {
                android.widget.Toast.makeText(
                    context, 
                    "جاري الطباعة المباشرة على الطابعة المربوطة حصراً: $printerName", 
                    android.widget.Toast.LENGTH_LONG
                ).show()
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val printAdapter = BitmapPrintAdapter(context, bitmap, jobName)
                
                val builder = PrintAttributes.Builder()
                // Configure standard thermal printer sizes or default layout sizing
                if (paperWidth == "58mm") {
                    builder.setMediaSize(PrintAttributes.MediaSize.ISO_A6)
                } else {
                    builder.setMediaSize(PrintAttributes.MediaSize.ISO_A5)
                }
                
                printManager.print(jobName, printAdapter, builder.build())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun generateReceiptBitmap(
        context: Context,
        invoice: Invoice,
        items: List<InvoiceItem>,
        paperWidth: String
    ): Bitmap {
        // Load latest app config values
        AppConfig.load(context)
        val restName = AppConfig.restaurantName
        val restPhone = AppConfig.restaurantPhone
        val restAddress = AppConfig.restaurantAddress

        // A thermal printer prints at 203 DPI. 58mm = ~384 px, 80mm = ~576 px
        val width = if (paperWidth == "58mm") 384 else 576
        
        // Calculate dynamic height based on item count
        val headerHeight = 280
        val itemHeight = 45
        val totalsHeight = 80
        val footerHeight = 120
        val dynamicHeight = headerHeight + (items.size * itemHeight) + totalsHeight + footerHeight
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        
        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 20f else 24f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        
        val normalPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 24f else 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        
        val centerPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        val rightPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.LEFT
        }

        val leftPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }

        var currentY = 50f
        
        // 1. Header (Restaurant Info)
        canvas.drawText(restName, (width / 2).toFloat(), currentY, titlePaint)
        currentY += 40f
        canvas.drawText("هاتف: $restPhone", (width / 2).toFloat(), currentY, centerPaint)
        currentY += 30f
        canvas.drawText(restAddress, (width / 2).toFloat(), currentY, centerPaint)
        currentY += 35f
        
        // Dash Divider
        val dashPath = android.graphics.DashPathEffect(floatArrayOf(10.0f, 5.0f), 0f)
        val dividerPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = dashPath
        }
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 30f
        
        // Invoice Meta Info (English numbers as requested)
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH)
        val formattedDate = sdf.format(Date(invoice.orderTime))
        
        paint.textSize = if (paperWidth == "58mm") 16f else 18f
        normalPaint.textSize = if (paperWidth == "58mm") 15f else 17f
        
        val typeStr = when (invoice.orderType) {
            "صالة" -> if (invoice.orderTypeDetails.isNotEmpty()) "صالة (طاولة: ${invoice.orderTypeDetails})" else "النوع: صالة"
            "دلفري" -> if (invoice.orderTypeDetails.isNotEmpty()) "دلفري (هاتف: ${invoice.orderTypeDetails})" else "النوع: دلفري"
            else -> "النوع: سفري"
        }
        canvas.drawText("رقم الوصل: #${invoice.invoiceNumber}", 15f, currentY, paint)
        canvas.drawText(typeStr, (width - 15).toFloat() - rightPaint.measureText(typeStr), currentY, paint)
        currentY += 35f
        canvas.drawText("التاريخ: $formattedDate", 15f, currentY, normalPaint)
        canvas.drawText("الدفع: ${invoice.paymentMethod}", (width - 15).toFloat() - rightPaint.measureText("الدفع: ${invoice.paymentMethod}"), currentY, normalPaint)
        currentY += 30f
        
        // Divider
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 30f
        
        // Table Headers
        val productX = 15f
        val qtyX = if (paperWidth == "58mm") 180f else 260f
        val priceX = if (paperWidth == "58mm") 265f else 390f
        val totalX = (width - 15).toFloat()
        
        canvas.drawText("المادة", productX, currentY, paint)
        canvas.drawText("العدد", qtyX, currentY, paint)
        canvas.drawText("السعر", priceX, currentY, paint)
        canvas.drawText("الإجمالي", totalX - leftPaint.measureText("الإجمالي"), currentY, paint)
        currentY += 25f
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 30f
        
        // Draw Items
        items.forEach { item ->
            val cleanName = item.productName
            val maxChars = if (paperWidth == "58mm") 14 else 20
            val displayName = if (cleanName.length > maxChars) cleanName.substring(0, maxChars - 3) + "..." else cleanName
            
            canvas.drawText(displayName, productX, currentY, normalPaint)
            canvas.drawText(item.quantity.toString(), qtyX, currentY, normalPaint)
            canvas.drawText(formatIraqiDinarEnglishNumbers(item.productPrice), priceX, currentY, normalPaint)
            val itemTotal = item.productPrice * item.quantity
            canvas.drawText(formatIraqiDinarEnglishNumbers(itemTotal), totalX - leftPaint.measureText(formatIraqiDinarEnglishNumbers(itemTotal)), currentY, normalPaint)
            currentY += itemHeight
        }
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 30f
        
        // Totals
        val totalLabelPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        
        val totalValuePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        
        val subTotalStr = formatIraqiDinarEnglishNumbers(invoice.totalAmount)
        // Final Total Only (No Subtotal, Tax, Received, or Change as requested)
        val finalTotalPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 18f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        val finalTotalValuePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 18f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.RIGHT
        }
        canvas.drawText("المجموع الكلي:", 15f, currentY, finalTotalPaint)
        canvas.drawText(subTotalStr, totalX, currentY, finalTotalValuePaint)
        currentY += 40f
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 30f
        
        // Footer
        canvas.drawText("شكراً لزيارتكم! نرجو رؤيتكم مجدداً", (width / 2).toFloat(), currentY, centerPaint)
        
        return bitmap
    }

    fun printShiftReport(
        context: Context,
        shiftName: String,
        startTime: Long,
        endTime: Long,
        openingCapital: Double,
        totalSales: Double
    ) {
        val prefs = context.getSharedPreferences("pos_app_prefs", Context.MODE_PRIVATE)
        val paperWidth = prefs.getString("selected_paper_size", "80mm") ?: "80mm"
        val printerName = prefs.getString("selected_printer_name", "طابعة الكاشير الافتراضية (Xprinter)") ?: "طابعة الكاشير الافتراضية (Xprinter)"
        
        val bitmap = generateShiftReportBitmap(context, shiftName, startTime, endTime, openingCapital, totalSales, paperWidth)
        val jobName = "تقرير_إغلاق_وردية_$shiftName"

        val activity = context as? android.app.Activity ?: return
        activity.runOnUiThread {
            try {
                val printManager = context.getSystemService(Context.PRINT_SERVICE) as PrintManager
                val printAdapter = BitmapPrintAdapter(context, bitmap, jobName)
                
                val builder = PrintAttributes.Builder()
                if (paperWidth == "58mm") {
                    builder.setMediaSize(PrintAttributes.MediaSize.ISO_A6)
                } else {
                    builder.setMediaSize(PrintAttributes.MediaSize.ISO_A5)
                }
                
                printManager.print(jobName, printAdapter, builder.build())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun generateShiftReportBitmap(
        context: Context,
        shiftName: String,
        startTime: Long,
        endTime: Long,
        openingCapital: Double,
        totalSales: Double,
        paperWidth: String
    ): Bitmap {
        AppConfig.load(context)
        val restName = AppConfig.restaurantName

        val width = if (paperWidth == "58mm") 384 else 576
        val dynamicHeight = 520
        
        val bitmap = Bitmap.createBitmap(width, dynamicHeight, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        
        val paint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 18f else 22f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
        
        val normalPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 15f else 17f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        }

        val titlePaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 22f else 26f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        
        val centerPaint = Paint().apply {
            color = Color.BLACK
            isAntiAlias = true
            textSize = if (paperWidth == "58mm") 16f else 18f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }

        var currentY = 50f
        
        // Header
        canvas.drawText(restName, (width / 2).toFloat(), currentY, titlePaint)
        currentY += 40f
        canvas.drawText("تقرير إغلاق الوردية", (width / 2).toFloat(), currentY, centerPaint)
        currentY += 35f
        
        val dashPath = android.graphics.DashPathEffect(floatArrayOf(10.0f, 5.0f), 0f)
        val dividerPaint = Paint().apply {
            color = Color.BLACK
            style = Paint.Style.STROKE
            strokeWidth = 2f
            pathEffect = dashPath
        }
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 30f
        
        val sdf = SimpleDateFormat("yyyy-MM-dd hh:mm a", Locale.ENGLISH)
        
        // Report Details
        canvas.drawText("اسم الكاشير: $shiftName", 15f, currentY, paint)
        currentY += 35f
        canvas.drawText("تاريخ الفتح: ${sdf.format(Date(startTime))}", 15f, currentY, normalPaint)
        currentY += 35f
        canvas.drawText("تاريخ الإغلاق: ${sdf.format(Date(endTime))}", 15f, currentY, normalPaint)
        currentY += 40f
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 35f
        
        // Calculations
        canvas.drawText("رأس المال الافتتاحي:", 15f, currentY, normalPaint)
        val capitalStr = formatIraqiDinarEnglishNumbers(openingCapital)
        canvas.drawText(capitalStr, (width - 15).toFloat() - normalPaint.measureText(capitalStr), currentY, normalPaint)
        currentY += 35f
        
        canvas.drawText("إجمالي المبيعات:", 15f, currentY, normalPaint)
        val salesStr = formatIraqiDinarEnglishNumbers(totalSales)
        canvas.drawText(salesStr, (width - 15).toFloat() - normalPaint.measureText(salesStr), currentY, normalPaint)
        currentY += 40f
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 35f
        
        // Total In Drawer
        val totalInDrawer = openingCapital + totalSales
        val totalInDrawerStr = formatIraqiDinarEnglishNumbers(totalInDrawer)
        canvas.drawText("إجمالي النقدية بالصندوق:", 15f, currentY, paint)
        canvas.drawText(totalInDrawerStr, (width - 15).toFloat() - paint.measureText(totalInDrawerStr), currentY, paint)
        currentY += 45f
        
        canvas.drawLine(10f, currentY, (width - 10).toFloat(), currentY, dividerPaint)
        currentY += 35f
        
        // Footer
        canvas.drawText("تم تصدير وحفظ التقرير بنجاح", (width / 2).toFloat(), currentY, centerPaint)
        
        return bitmap
    }
    
    private fun formatIraqiDinarEnglishNumbers(amount: Double): String {
        return String.format(Locale.ENGLISH, "%,.0f د.ع", amount)
    }
}

class BitmapPrintAdapter(
    private val context: Context,
    private val bitmap: Bitmap,
    private val jobName: String
) : PrintDocumentAdapter() {

    private var pdfDocument: PrintedPdfDocument? = null

    override fun onLayout(
        oldAttributes: PrintAttributes?,
        newAttributes: PrintAttributes,
        cancellationSignal: CancellationSignal?,
        callback: LayoutResultCallback,
        metadata: Bundle?
    ) {
        if (cancellationSignal?.isCanceled == true) {
            callback.onLayoutCancelled()
            return
        }

        pdfDocument = PrintedPdfDocument(context, newAttributes)

        val info = PrintDocumentInfo.Builder(jobName)
            .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
            .setPageCount(1)
            .build()

        callback.onLayoutFinished(info, true)
    }

    override fun onWrite(
        pages: Array<out PageRange>?,
        destination: ParcelFileDescriptor?,
        cancellationSignal: CancellationSignal?,
        callback: WriteResultCallback?
    ) {
        val pdfDoc = pdfDocument ?: return
        val page = pdfDoc.startPage(0)

        val canvas = page.canvas
        
        val pageRect = canvas.clipBounds
        val scaleX = pageRect.width().toFloat() / bitmap.width.toFloat()
        val scaleY = pageRect.height().toFloat() / bitmap.height.toFloat()
        val scale = Math.min(scaleX, scaleY)
        
        val matrix = Matrix().apply {
            postScale(scale, scale)
            val left = (pageRect.width() - (bitmap.width * scale)) / 2f
            postTranslate(left, 10f)
        }
        
        canvas.drawBitmap(bitmap, matrix, Paint().apply { isAntiAlias = true; isFilterBitmap = true })

        pdfDoc.finishPage(page)

        try {
            pdfDoc.writeTo(FileOutputStream(destination?.fileDescriptor))
        } catch (e: Exception) {
            callback?.onWriteFailed(e.toString())
            return
        } finally {
            pdfDoc.close()
            pdfDocument = null
        }

        callback?.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
    }
}
