package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface POSDao {

    // --- Category Queries ---
    @Query("SELECT * FROM categories ORDER BY id ASC")
    fun getAllCategories(): Flow<List<Category>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCategory(category: Category): Long

    @Update
    suspend fun updateCategory(category: Category)

    @Delete
    suspend fun deleteCategory(category: Category)


    // --- Product Queries ---
    @Query("SELECT * FROM products ORDER BY id DESC")
    fun getAllProducts(): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE categoryId = :categoryId ORDER BY id DESC")
    fun getProductsByCategory(categoryId: Int): Flow<List<Product>>

    @Query("SELECT * FROM products WHERE name LIKE :query ORDER BY id DESC")
    fun searchProducts(query: String): Flow<List<Product>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProduct(product: Product): Long

    @Update
    suspend fun updateProduct(product: Product)

    @Delete
    suspend fun deleteProduct(product: Product)


    // --- Invoice Queries ---
    @Query("SELECT * FROM invoices ORDER BY invoiceNumber DESC")
    fun getAllInvoices(): Flow<List<Invoice>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoice(invoice: Invoice): Long

    @Query("SELECT * FROM invoices WHERE invoiceNumber = :invoiceNumber")
    suspend fun getInvoiceById(invoiceNumber: Long): Invoice?


    // --- Invoice Item Queries ---
    @Query("SELECT * FROM invoice_items WHERE invoiceNumber = :invoiceNumber")
    fun getItemsForInvoice(invoiceNumber: Long): Flow<List<InvoiceItem>>

    @Query("SELECT * FROM invoice_items ORDER BY id DESC")
    fun getAllInvoiceItems(): Flow<List<InvoiceItem>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertInvoiceItem(item: InvoiceItem)


    // --- Shift Log Queries ---
    @Query("SELECT * FROM shift_logs ORDER BY id DESC")
    fun getAllShiftLogs(): Flow<List<ShiftLog>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertShiftLog(shiftLog: ShiftLog): Long

    @Update
    suspend fun updateShiftLog(shiftLog: ShiftLog)

    @Delete
    suspend fun deleteShiftLog(shiftLog: ShiftLog)

    @Delete
    suspend fun deleteInvoice(invoice: Invoice)

    @Query("DELETE FROM invoice_items WHERE invoiceNumber = :invoiceNumber")
    suspend fun deleteInvoiceItemsByInvoiceNo(invoiceNumber: Long)

    @Query("DELETE FROM categories")
    suspend fun clearCategories()

    @Query("DELETE FROM products")
    suspend fun clearProducts()

    @Query("DELETE FROM invoices")
    suspend fun clearInvoices()

    @Query("DELETE FROM invoice_items")
    suspend fun clearInvoiceItems()

    @Query("DELETE FROM shift_logs")
    suspend fun clearShiftLogs()
}
